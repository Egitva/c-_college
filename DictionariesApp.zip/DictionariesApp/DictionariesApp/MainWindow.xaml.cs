﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
//using System.Windows.Shapes;
using Microsoft.VisualBasic;
using System.Xml;

namespace DictionariesApp
{
    public partial class MainWindow : Window
    {
        private const string DictionariesDir = "Dictionaries";
        private Dictionary<string, DictData> loadedDictionaries = new Dictionary<string, DictData>();
        private string currentDictName = null;

        public class TranslationEntry
        {
            public string Word { get; set; }
            public List<string> Translations { get; set; } = new List<string>();
        }

        public class DictData
        {
            public string Name { get; set; }
            public string SourceLang { get; set; }
            public string TargetLang { get; set; }
            public List<TranslationEntry> Entries { get; set; } = new List<TranslationEntry>();
        }

        public MainWindow()
        {
            InitializeComponent();
            Directory.CreateDirectory(DictionariesDir);
            LoadAllDictionaries();
            ShowMainMenu();
        }

        private void LoadAllDictionaries()
        {
            loadedDictionaries.Clear();
            foreach (var file in Directory.GetFiles(DictionariesDir, "*.json"))
            {
                try
                {
                    string json = File.ReadAllText(file);
                    DictData data = JsonConvert.DeserializeObject<DictData>(json);
                    if (data != null)
                        loadedDictionaries[data.Name] = data;
                }
                catch { }
            }
        }

        private void SaveDictionary(string dictName)
        {
            if (loadedDictionaries.TryGetValue(dictName, out DictData data))
            {
                string json = JsonConvert.SerializeObject(data, Newtonsoft.Json.Formatting.Indented);
                File.WriteAllText(Path.Combine(DictionariesDir, $"{dictName}.json"), json);
            }
        }

        private void ShowMainMenu()
        {
            Title = "Словари - Главное меню";
            var panel = CreateMainPanel("Приложение «Словари»");

            AddButton(panel, "Создать новый словарь", CreateDictionary);
            AddButton(panel, "Открыть существующий словарь", OpenDictionaryList);
            AddButton(panel, "Поиск перевода (по всем словарям)", GlobalSearch);
            AddButton(panel, "Выход", () => Application.Current.Shutdown());

            Content = panel;
        }

        private StackPanel CreateMainPanel(string titleText)
        {
            var panel = new StackPanel { Margin = new Thickness(30) };
            var title = new TextBlock
            {
                Text = titleText,
                FontSize = 26,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 0, 30)
            };
            panel.Children.Add(title);
            return panel;
        }

        private void AddButton(StackPanel panel, string text, Action action)
        {
            var btn = new Button
            {
                Content = text,
                Margin = new Thickness(0, 8, 0, 8),
                Height = 45,
                FontSize = 16
            };
            btn.Click += (s, e) => action();
            panel.Children.Add(btn);
        }

        private void CreateDictionary()
        {
            var grid = new Grid { Margin = new Thickness(30) };
            for (int i = 0; i < 8; i++)
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            var tbName = new TextBox { Margin = new Thickness(0, 5,0,0) };
            var tbSource = new TextBox { Text = "English", Margin = new Thickness(0, 5, 0, 0) };
            var tbTarget = new TextBox { Text = "Russian", Margin = new Thickness(0, 5, 0, 0) };

            var btnCreate = new Button { Content = "Создать словарь", Height = 40, Margin = new Thickness(0, 15, 0, 5) };
            var btnBack = new Button { Content = "Назад", Height = 40 };

            grid.Children.Add(new TextBlock { Text = "Название словаря:", Margin = new Thickness(0, 10, 0, 5) }); Grid.SetRow(grid.Children[0], 0);
            grid.Children.Add(tbName); Grid.SetRow(tbName, 1);
            grid.Children.Add(new TextBlock { Text = "Язык-источник:", Margin = new Thickness(0, 10, 0, 5) }); Grid.SetRow(grid.Children[2], 2);
            grid.Children.Add(tbSource); Grid.SetRow(tbSource, 3);
            grid.Children.Add(new TextBlock { Text = "Язык-перевод:", Margin = new Thickness(0, 10, 0, 5) }); Grid.SetRow(grid.Children[4], 4);
            grid.Children.Add(tbTarget); Grid.SetRow(tbTarget, 5);
            grid.Children.Add(btnCreate); Grid.SetRow(btnCreate, 6);
            grid.Children.Add(btnBack); Grid.SetRow(btnBack, 7);

            btnCreate.Click += (s, e) =>
            {
                string name = tbName.Text.Trim();
                if (string.IsNullOrEmpty(name) || loadedDictionaries.ContainsKey(name))
                {
                    MessageBox.Show("Введите корректное уникальное название!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var data = new DictData
                {
                    Name = name,
                    SourceLang = tbSource.Text.Trim(),
                    TargetLang = tbTarget.Text.Trim()
                };

                loadedDictionaries[name] = data;
                SaveDictionary(name);
                MessageBox.Show($"Словарь «{name}» успешно создан!", "Успех");
                currentDictName = name;
                ShowDictionaryMenu();
            };

            btnBack.Click += (s, e) => ShowMainMenu();

            Content = grid;
        }

        private void OpenDictionaryList()
        {
            var panel = CreateMainPanel("Выберите словарь");

            var listBox = new ListBox { Margin = new Thickness(0, 10, 0, 0), FontSize = 15 };
            listBox.ItemsSource = loadedDictionaries.Keys.OrderBy(x => x).ToList();

            var btnOpen = new Button { Content = "Открыть", Height = 40, Margin = new Thickness(0, 10, 10, 0) };
            var btnBack = new Button { Content = "Назад", Height = 40 };

            btnOpen.Click += (s, e) =>
            {
                if (listBox.SelectedItem is string selected)
                {
                    currentDictName = selected;
                    ShowDictionaryMenu();
                }
                else
                    MessageBox.Show("Выберите словарь из списка.");
            };

            btnBack.Click += (s, e) => ShowMainMenu();

            var btnPanel = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center };
            btnPanel.Children.Add(btnOpen);
            btnPanel.Children.Add(btnBack);

            panel.Children.Add(listBox);
            panel.Children.Add(btnPanel);

            Content = panel;
        }

        private void ShowDictionaryMenu()
        {
            if (!loadedDictionaries.TryGetValue(currentDictName, out DictData dict))
                return;

            Title = $"Словарь: {currentDictName}";

            var panel = CreateMainPanel($"{dict.SourceLang} → {dict.TargetLang}");

            AddButton(panel, "Добавить слово + перевод", () => AddWord(dict));
            AddButton(panel, "Просмотреть все слова", () => ShowWordsList(dict));
            AddButton(panel, "Поиск в этом словаре", () => SearchInCurrentDict(dict));
            AddButton(panel, "Экспортировать слово", () => ExportWord(dict));
            AddButton(panel, "Удалить этот словарь", DeleteCurrentDict);
            AddButton(panel, "← Назад в главное меню", ShowMainMenu);

            Content = panel;
        }

        private void AddWord(DictData dict)
        {
            var win = new Window
            {
                Title = "Добавить слово",
                Width = 420,
                Height = 280,
                Owner = this,
                WindowStartupLocation = WindowStartupLocation.CenterOwner
            };

            var sp = new StackPanel { Margin = new Thickness(20) };

            var tbWord = new TextBox { Margin = new Thickness(0, 5, 0, 0) };
            var tbTrans = new TextBox { Margin = new Thickness(0, 5, 0, 0), Height = 80, AcceptsReturn = true };

            var btnAdd = new Button { Content = "Добавить", Margin = new Thickness(0, 15, 0, 5), Height = 35 };
            var btnCancel = new Button { Content = "Отмена", Height = 35 };

            sp.Children.Add(new TextBlock { Text = "Слово:" });
            sp.Children.Add(tbWord);
            sp.Children.Add(new TextBlock { Text = "Перевод(ы) (через точку с запятой ;):", Margin = new Thickness(0, 10, 0, 5) });
            sp.Children.Add(tbTrans);
            sp.Children.Add(btnAdd);
            sp.Children.Add(btnCancel);

            btnAdd.Click += (s, e) =>
            {
                string word = tbWord.Text.Trim();
                if (string.IsNullOrEmpty(word)) return;

                var translations = tbTrans.Text.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                                               .Select(t => t.Trim())
                                               .Where(t => !string.IsNullOrEmpty(t))
                                               .ToList();

                var entry = dict.Entries.FirstOrDefault(en =>
                    en.Word.Equals(word, StringComparison.OrdinalIgnoreCase));

                if (entry == null)
                {
                    entry = new TranslationEntry { Word = word };
                    dict.Entries.Add(entry);
                }

                foreach (var t in translations)
                {
                    if (!entry.Translations.Contains(t, StringComparer.OrdinalIgnoreCase))
                        entry.Translations.Add(t);
                }

                SaveDictionary(dict.Name);
                MessageBox.Show("Слово успешно добавлено!");
                win.Close();
                ShowDictionaryMenu();
            };

            btnCancel.Click += (s, e) => win.Close();

            win.Content = sp;
            win.ShowDialog();
        }

        private void ShowWordsList(DictData dict)
        {
            var win = new Window
            {
                Title = "Список слов в словаре",
                Width = 700,
                Height = 500,
                Owner = this
            };

            var lv = new ListView();
            var gv = new GridView();
            lv.View = gv;

            gv.Columns.Add(new GridViewColumn { Header = "Слово", Width = 200, DisplayMemberBinding = new System.Windows.Data.Binding("Word") });
            gv.Columns.Add(new GridViewColumn { Header = "Переводы", Width = 450, DisplayMemberBinding = new System.Windows.Data.Binding("TranslationsStr") });

            var items = dict.Entries.Select(e => new
            {
                Word = e.Word,
                TranslationsStr = string.Join("; ", e.Translations)
            }).ToList();

            lv.ItemsSource = items;

            var sp = new StackPanel { Margin = new Thickness(15) };
            sp.Children.Add(new TextBlock { Text = $"Слов в словаре: {items.Count}", FontSize = 16, Margin = new Thickness(0, 0, 0, 10) });
            sp.Children.Add(lv);

            var btnClose = new Button { Content = "Закрыть", Width = 120, Height = 35, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 15, 0, 0) };
            btnClose.Click += (s, e) => win.Close();

            sp.Children.Add(btnClose);
            win.Content = sp;
            win.ShowDialog();
        }

        private void SearchInCurrentDict(DictData dict)
        {
            string word = Microsoft.VisualBasic.Interaction.InputBox("Введите слово для поиска:", "Поиск в словаре", "");
            if (string.IsNullOrWhiteSpace(word)) return;

            var entry = dict.Entries.FirstOrDefault(e =>
                e.Word.Equals(word, StringComparison.OrdinalIgnoreCase));

            if (entry != null)
                MessageBox.Show($"Переводы:\n\n{string.Join("\n", entry.Translations)}", "Результат поиска", MessageBoxButton.OK, MessageBoxImage.Information);
            else
                MessageBox.Show("Слово не найдено.", "Результат", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void GlobalSearch()
        {
            string word = Microsoft.VisualBasic.Interaction.InputBox("Введите слово для поиска по всем словарям:", "Глобальный поиск", "");
            if (string.IsNullOrWhiteSpace(word)) return;

            foreach (var dict in loadedDictionaries.Values)
            {
                var entry = dict.Entries.FirstOrDefault(e =>
                    e.Word.Equals(word, StringComparison.OrdinalIgnoreCase));

                if (entry != null)
                {
                    MessageBox.Show($"Найдено в словаре «{dict.Name}»:\n\n{string.Join("\n", entry.Translations)}",
                        "Результат", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
            }
            MessageBox.Show("Слово не найдено ни в одном словаре.");
        }

        private void ExportWord(DictData dict)
        {
            string word = Microsoft.VisualBasic.Interaction.InputBox("Введите слово для экспорта:", "Экспорт", "");
            if (string.IsNullOrWhiteSpace(word)) return;

            var entry = dict.Entries.FirstOrDefault(e => e.Word.Equals(word, StringComparison.OrdinalIgnoreCase));
            if (entry == null)
            {
                MessageBox.Show("Слово не найдено.");
                return;
            }

            string content = $"{dict.SourceLang}: {entry.Word}\n" +
                             $"{dict.TargetLang}:\n" +
                             string.Join("\n", entry.Translations);

            string path = Path.Combine(DictionariesDir, $"Export_{entry.Word}_{DateTime.Now:yyyyMMdd_HHmm}.txt");
            File.WriteAllText(path, content);

            MessageBox.Show($"Слово успешно экспортировано!\n\n{path}", "Экспорт");
        }

        private void DeleteCurrentDict()
        {
            if (MessageBox.Show($"Удалить словарь «{currentDictName}»?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                string filePath = Path.Combine(DictionariesDir, $"{currentDictName}.json");
                if (File.Exists(filePath))
                    File.Delete(filePath);

                loadedDictionaries.Remove(currentDictName);
                currentDictName = null;
                MessageBox.Show("Словарь удалён.");
                ShowMainMenu();
            }
        }
    }
}

