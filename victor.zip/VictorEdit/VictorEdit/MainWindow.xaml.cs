﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Newtonsoft.Json;
using System.IO;


namespace VictorEdit
{
    public partial class MainWindow : Window
    {
        private const string UsersFile = "EditorUsers.json";
        private const string QuizzesFolder = "Quizzes";

        private EditorUser currentUser = null;
        private List<EditorUser> editorUsers = new List<EditorUser>();
        private List<Quiz> quizzes = new List<Quiz>();

        // ===================== МОДЕЛИ =====================
        public class EditorUser
        {
            public string Login { get; set; }
            public string PasswordHash { get; set; }
        }

        public class Answer
        {
            public string Text { get; set; }
            public bool IsCorrect { get; set; }
        }

        public class Question
        {
            public string Text { get; set; }
            public List<Answer> Answers { get; set; } = new List<Answer>();
        }

        public class Quiz
        {
            public string Name { get; set; }
            public List<Question> Questions { get; set; } = new List<Question>();
        }

        public MainWindow()
        {
            InitializeComponent();
            EnsureFolders();
            LoadEditorUsers();
            LoadQuizzes();
            CreateDefaultAdmin();
            ShowLoginScreen();
        }

        private void EnsureFolders()
        {
            string path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, QuizzesFolder);
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        }

        private string GetFullPath(string relative) => System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relative);

        private string ReadAllTextSafe(string relative)
        {
            try
            {
                string p = GetFullPath(relative);
                return File.Exists(p) ? File.ReadAllText(p, Encoding.UTF8) : null;
            }
            catch { return null; }
        }

        private void WriteAllTextSafe(string relative, string content)
        {
            try
            {
                File.WriteAllText(GetFullPath(relative), content, Encoding.UTF8);
            }
            catch (Exception ex) { MessageBox.Show("Ошибка записи: " + ex.Message); }
        }

        private void LoadEditorUsers()
        {
            string json = ReadAllTextSafe(UsersFile);
            if (!string.IsNullOrEmpty(json))
                editorUsers = JsonConvert.DeserializeObject<List<EditorUser>>(json) ?? new List<EditorUser>();
        }

        private void SaveEditorUsers()
        {
            string json = JsonConvert.SerializeObject(editorUsers, Formatting.Indented);
            WriteAllTextSafe(UsersFile, json);
        }

        private void LoadQuizzes()
        {
            quizzes.Clear();
            string dir = GetFullPath(QuizzesFolder);
            foreach (var file in Directory.GetFiles(dir, "*.json"))
            {
                try
                {
                    string json = File.ReadAllText(file, Encoding.UTF8);
                    var quiz = JsonConvert.DeserializeObject<Quiz>(json);
                    if (quiz != null) quizzes.Add(quiz);
                }
                catch { }
            }
        }

        private void SaveQuiz(Quiz quiz)
        {
            string fileName = quiz.Name.Replace(" ", "_").Replace("/", "_") + ".json";
            string json = JsonConvert.SerializeObject(quiz, Formatting.Indented);
            WriteAllTextSafe(System.IO.Path.Combine(QuizzesFolder, fileName), json);
        }

        private string GetHash(string pass) => pass.GetHashCode().ToString();

        private void CreateDefaultAdmin()
        {
            if (!editorUsers.Any(u => u.Login == "admin"))
            {
                editorUsers.Add(new EditorUser { Login = "admin", PasswordHash = GetHash("admin123") });
                SaveEditorUsers();
            }
        }

        // ===================== ЛОГИН =====================
        private void ShowLoginScreen()
        {
            var panel = new StackPanel { Margin = new Thickness(50) };

            panel.Children.Add(new TextBlock
            {
                Text = "QuizEditor",
                FontSize = 32,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 0, 40)
            });

            var tbLogin = new TextBox { Height = 35, Margin = new Thickness(0, 10,0,0) };
            var pbPass = new PasswordBox { Height = 35, Margin = new Thickness(0, 10,0,0) };

            var btnLogin = new Button { Content = "Войти", Height = 45, Margin = new Thickness(0, 20, 0, 10), FontSize = 16 };
            var btnExit = new Button { Content = "Выход", Height = 45, FontSize = 16 };

            panel.Children.Add(new TextBlock { Text = "Логин" });
            panel.Children.Add(tbLogin);
            panel.Children.Add(new TextBlock { Text = "Пароль", Margin = new Thickness(0, 15, 0, 5) });
            panel.Children.Add(pbPass);
            panel.Children.Add(btnLogin);
            panel.Children.Add(btnExit);

            btnLogin.Click += (s, e) =>
            {
                var user = editorUsers.FirstOrDefault(u =>
                    u.Login.Equals(tbLogin.Text, StringComparison.OrdinalIgnoreCase) &&
                    u.PasswordHash == GetHash(pbPass.Password));

                if (user != null)
                {
                    currentUser = user;
                    ShowMainEditorMenu();
                }
                else
                    MessageBox.Show("Неверный логин или пароль!", "Ошибка");
            };

            btnExit.Click += (s, e) => Application.Current.Shutdown();

            Content = panel;
        }

        private void ShowMainEditorMenu()
        {
            Title = $"QuizEditor — {currentUser.Login}";
            var panel = new StackPanel { Margin = new Thickness(50) };

            panel.Children.Add(new TextBlock
            {
                Text = "Редактор викторин",
                FontSize = 28,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 0, 40)
            });

            AddButton(panel, "Создать новую викторину", CreateNewQuiz);
            AddButton(panel, "Редактировать существующие викторины", EditQuizzesList);
            AddButton(panel, "Выход из аккаунта", () => { currentUser = null; ShowLoginScreen(); });

            Content = panel;
        }

        private void AddButton(StackPanel p, string text, Action action)
        {
            var btn = new Button { Content = text, Height = 55, Margin = new Thickness(0, 12,0,0), FontSize = 16 };
            btn.Click += (s, e) => action();
            p.Children.Add(btn);
        }

        // ===================== СОЗДАНИЕ ВИКТОРИНЫ =====================
        private void CreateNewQuiz()
        {
            string name = Microsoft.VisualBasic.Interaction.InputBox("Введите название викторины:", "Новая викторина", "Новая тема");
            if (string.IsNullOrWhiteSpace(name)) return;

            if (quizzes.Any(q => q.Name.Equals(name, StringComparison.OrdinalIgnoreCase)))
            {
                MessageBox.Show("Викторина с таким названием уже существует!");
                return;
            }

            var newQuiz = new Quiz { Name = name };
            quizzes.Add(newQuiz);
            SaveQuiz(newQuiz);
            EditQuiz(newQuiz);
        }

        private void EditQuizzesList()
        {
            var win = new Window { Title = "Выберите викторину для редактирования", Width = 500, Height = 400, Owner = this };
            var sp = new StackPanel { Margin = new Thickness(20) };

            var listBox = new ListBox { FontSize = 15 };
            foreach (var q in quizzes) listBox.Items.Add(q.Name);

            var btnEdit = new Button { Content = "Редактировать", Height = 40, Margin = new Thickness(0, 15,0,0) };
            var btnDelete = new Button { Content = "Удалить", Height = 40, Margin = new Thickness(0, 5,0,0) };

            btnEdit.Click += (s, e) =>
            {
                if (listBox.SelectedItem is string selectedName)
                {
                    var quiz = quizzes.FirstOrDefault(q => q.Name == selectedName);
                    if (quiz != null)
                    {
                        win.Close();
                        EditQuiz(quiz);
                    }
                }
            };

            btnDelete.Click += (s, e) =>
            {
                if (listBox.SelectedItem is string selectedName)
                {
                    if (MessageBox.Show($"Удалить викторину «{selectedName}»?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    {
                        var quiz = quizzes.FirstOrDefault(q => q.Name == selectedName);
                        if (quiz != null)
                        {
                            quizzes.Remove(quiz);
                            string file = GetFullPath(System.IO.Path.Combine(QuizzesFolder, selectedName.Replace(" ", "_") + ".json"));
                            if (File.Exists(file)) File.Delete(file);
                            MessageBox.Show("Викторина удалена.");
                            win.Close();
                            EditQuizzesList();
                        }
                    }
                }
            };

            sp.Children.Add(new TextBlock { Text = "Существующие викторины:", FontSize = 18 });
            sp.Children.Add(listBox);
            sp.Children.Add(btnEdit);
            sp.Children.Add(btnDelete);

            win.Content = sp;
            win.ShowDialog();
        }

        // ===================== РЕДАКТИРОВАНИЕ ВИКТОРИНЫ =====================
        private void EditQuiz(Quiz quiz)
        {
            var win = new Window
            {
                Title = $"Редактирование: {quiz.Name}",
                Width = 950,
                Height = 650,
                Owner = this
            };

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(300) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            // Список вопросов
            var questionsList = new ListBox { Margin = new Thickness(10) };
            RefreshQuestionsList(questionsList, quiz);

            var btnAddQuestion = new Button { Content = "Добавить вопрос", Height = 40, Margin = new Thickness(10) };

            var leftPanel = new StackPanel();
            leftPanel.Children.Add(new TextBlock { Text = "Вопросы", FontSize = 18, Margin = new Thickness(10) });
            leftPanel.Children.Add(questionsList);
            leftPanel.Children.Add(btnAddQuestion);

            Grid.SetColumn(leftPanel, 0);

            // Правая панель — редактирование вопроса
            var rightPanel = new StackPanel { Margin = new Thickness(10) };
            var currentQuestionText = new TextBlock { Text = "Выберите вопрос слева", FontSize = 16 };

            rightPanel.Children.Add(currentQuestionText);

            Grid.SetColumn(rightPanel, 1);

            grid.Children.Add(leftPanel);
            grid.Children.Add(rightPanel);

            btnAddQuestion.Click += (s, e) =>
            {
                var q = new Question { Text = "Новый вопрос" };
                quiz.Questions.Add(q);
                SaveQuiz(quiz);
                RefreshQuestionsList(questionsList, quiz);
                EditQuestion(q, quiz, rightPanel, questionsList);
            };

            questionsList.SelectionChanged += (s, e) =>
            {
                if (questionsList.SelectedIndex >= 0)
                {
                    var selectedQ = quiz.Questions[questionsList.SelectedIndex];
                    EditQuestion(selectedQ, quiz, rightPanel, questionsList);
                }
            };

            win.Content = grid;
            win.ShowDialog();
        }

        private void RefreshQuestionsList(ListBox listBox, Quiz quiz)
        {
            listBox.Items.Clear();
            for (int i = 0; i < quiz.Questions.Count; i++)
            {
                listBox.Items.Add($"#{i + 1} {quiz.Questions[i].Text.Substring(0, Math.Min(60, quiz.Questions[i].Text.Length))}");
            }
        }

        private void EditQuestion(Question question, Quiz quiz, StackPanel rightPanel, ListBox questionsList)
        {
            rightPanel.Children.Clear();

            var tbQuestion = new TextBox
            {
                Text = question.Text,
                Height = 80,
                AcceptsReturn = true,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 10,0,0)
            };

            rightPanel.Children.Add(new TextBlock { Text = "Текст вопроса:", FontSize = 16 });
            rightPanel.Children.Add(tbQuestion);

            var answersPanel = new StackPanel();
            rightPanel.Children.Add(new TextBlock { Text = "Варианты ответов:", Margin = new Thickness(0, 15, 0, 5), FontSize = 16 });
            rightPanel.Children.Add(answersPanel);

            // Существующие ответы
            foreach (var ans in question.Answers)
            {
                AddAnswerControl(answersPanel, ans, question, quiz);
            }

            // Кнопки
            var btnAddAnswer = new Button { Content = "Добавить вариант ответа", Height = 35, Margin = new Thickness(0, 10,0,0) };
            var btnSave = new Button { Content = "Сохранить вопрос", Height = 40, Margin = new Thickness(0, 10,0,0) };

            rightPanel.Children.Add(btnAddAnswer);
            rightPanel.Children.Add(btnSave);

            btnAddAnswer.Click += (s, e) =>
            {
                var newAns = new Answer { Text = "Новый вариант" };
                question.Answers.Add(newAns);
                AddAnswerControl(answersPanel, newAns, question, quiz);
            };

            btnSave.Click += (s, e) =>
            {
                question.Text = tbQuestion.Text.Trim();
                SaveQuiz(quiz);
                RefreshQuestionsList(questionsList, quiz);
                MessageBox.Show("Вопрос сохранён!");
            };
        }

        private void AddAnswerControl(StackPanel panel, Answer answer, Question question, Quiz quiz)
        {
            var sp = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5,0,0) };
            var tb = new TextBox { Text = answer.Text, Width = 500, Height = 28 };
            var cb = new CheckBox { Content = "Правильный", IsChecked = answer.IsCorrect, Margin = new Thickness(10, 0, 0, 0) };
            var btnDel = new Button { Content = "Удалить", Width = 80 };

            tb.TextChanged += (s, e) => answer.Text = tb.Text;
            cb.Checked += (s, e) => answer.IsCorrect = true;
            cb.Unchecked += (s, e) => answer.IsCorrect = false;

            btnDel.Click += (s, e) =>
            {
                question.Answers.Remove(answer);
                panel.Children.Remove(sp);
                SaveQuiz(quiz);
            };

            sp.Children.Add(tb);
            sp.Children.Add(cb);
            sp.Children.Add(btnDel);
            panel.Children.Add(sp);
        }
    }
}
