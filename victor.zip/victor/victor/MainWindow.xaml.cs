﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Newtonsoft.Json;
using System.IO;

namespace victor
{
    public partial class MainWindow : Window
    {
        private const string UsersFile = "Users.json";
        private const string QuizzesFolder = "Quizzes";

        private User currentUser = null;
        private List<User> users = new List<User>();
        private List<Quiz> quizzes = new List<Quiz>();

        // ===================== МОДЕЛИ =====================
        public class User
        {
            public string Login { get; set; }
            public string PasswordHash { get; set; }
            public DateTime BirthDate { get; set; }
            public List<QuizResult> Results { get; set; } = new List<QuizResult>();
        }

        public class QuizResult
        {
            public string QuizName { get; set; }
            public int Score { get; set; } // 0-20
            public DateTime Date { get; set; }
        }

        public class Answer
        {
            public string Text { get; set; }
            public bool IsCorrect { get; set; }
        }

        public class Question
        {
            public string Text { get; set; }
            public List<Answer> Answers { get; set; } = new List<Answer>();
        }

        public class Quiz
        {
            public string Name { get; set; }
            public List<Question> Questions { get; set; } = new List<Question>();
        }

        public MainWindow()
        {
            InitializeComponent();
            EnsureAppFolders();
            LoadUsers();
            LoadQuizzes();
            CreateSampleDataIfNeeded();
            ShowLoginScreen();
        }

        private void EnsureAppFolders()
        {
            string quizzesPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, QuizzesFolder);
            if (!Directory.Exists(quizzesPath))
                Directory.CreateDirectory(quizzesPath);
        }

        private string GetFullPath(string relative) => System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relative);

        private string ReadAllTextSafe(string relativePath)
        {
            try
            {
                string path = GetFullPath(relativePath);
                return File.Exists(path) ? File.ReadAllText(path, Encoding.UTF8) : null;
            }
            catch { return null; }
        }

        private void WriteAllTextSafe(string relativePath, string content)
        {
            try
            {
                File.WriteAllText(GetFullPath(relativePath), content, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка записи: {ex.Message}");
            }
        }

        private void LoadUsers()
        {
            string json = ReadAllTextSafe(UsersFile);
            if (!string.IsNullOrEmpty(json))
                users = JsonConvert.DeserializeObject<List<User>>(json) ?? new List<User>();
        }

        private void SaveUsers()
        {
            string json = JsonConvert.SerializeObject(users, Formatting.Indented);
            WriteAllTextSafe(UsersFile, json);
        }

        private void LoadQuizzes()
        {
            quizzes.Clear();
            string dir = GetFullPath(QuizzesFolder);
            foreach (var file in Directory.GetFiles(dir, "*.json"))
            {
                try
                {
                    string json = File.ReadAllText(file, Encoding.UTF8);
                    var quiz = JsonConvert.DeserializeObject<Quiz>(json);
                    if (quiz != null) quizzes.Add(quiz);
                }
                catch { }
            }
        }

        private void SaveQuiz(Quiz quiz)
        {
            string fileName = quiz.Name.Replace(" ", "_").Replace("/", "_") + ".json";
            string json = JsonConvert.SerializeObject(quiz, Formatting.Indented);
            WriteAllTextSafe(System.IO.Path.Combine(QuizzesFolder, fileName), json);
        }

        private string GetHash(string password) => password.GetHashCode().ToString();

        private void CreateSampleDataIfNeeded()
        {
            if (!quizzes.Any())
            {
                var history = new Quiz { Name = "История" };
                history.Questions.Add(new Question
                {
                    Text = "Кто был первым президентом США?",
                    Answers = new List<Answer>
                    {
                        new Answer { Text = "Джордж Вашингтон", IsCorrect = true },
                        new Answer { Text = "Авраам Линкольн", IsCorrect = false },
                        new Answer { Text = "Томас Джефферсон", IsCorrect = false }
                    }
                });
                // Добавьте ещё вопросы по желанию...
                quizzes.Add(history);
                SaveQuiz(history);
            }

            if (!users.Any(u => u.Login == "admin"))
            {
                users.Add(new User { Login = "admin", PasswordHash = GetHash("123"), BirthDate = new DateTime(2000, 1, 1) });
                SaveUsers();
            }
        }

        // ===================== ЭКРАНЫ =====================
        private void ShowLoginScreen()
        {
            var panel = new StackPanel { Margin = new Thickness(60) };

            panel.Children.Add(new TextBlock { Text = "Викторина", FontSize = 32, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 0, 0, 40) });

            var tbLogin = new TextBox { Height = 35, Margin = new Thickness(0, 10,0,0) };
            var pbPass = new PasswordBox { Height = 35, Margin = new Thickness(0, 10,0,0) };

            var btnLogin = new Button { Content = "Войти", Height = 45, Margin = new Thickness(0, 20, 0, 10), FontSize = 16 };
            var btnReg = new Button { Content = "Регистрация", Height = 45, FontSize = 16 };

            panel.Children.Add(new TextBlock { Text = "Логин" });
            panel.Children.Add(tbLogin);
            panel.Children.Add(new TextBlock { Text = "Пароль", Margin = new Thickness(0, 15, 0, 5) });
            panel.Children.Add(pbPass);
            panel.Children.Add(btnLogin);
            panel.Children.Add(btnReg);

            btnLogin.Click += (s, e) =>
            {
                var user = users.FirstOrDefault(u => u.Login.Equals(tbLogin.Text, StringComparison.OrdinalIgnoreCase) &&
                                                     u.PasswordHash == GetHash(pbPass.Password));
                if (user != null)
                {
                    currentUser = user;
                    ShowMainMenu();
                }
                else MessageBox.Show("Неверные данные!", "Ошибка");
            };

            btnReg.Click += (s, e) => ShowRegistration();

            Content = panel;
        }

        private void ShowRegistration()
        {
            var win = new Window { Title = "Регистрация", Width = 450, Height = 320, Owner = this, WindowStartupLocation = WindowStartupLocation.CenterOwner };

            var sp = new StackPanel { Margin = new Thickness(30) };
            var tbLogin = new TextBox { Height = 30 };
            var pbPass = new PasswordBox { Height = 30 };
            var dpBirth = new DatePicker { SelectedDate = DateTime.Now.AddYears(-18) };

            var btnOk = new Button { Content = "Зарегистрироваться", Height = 40, Margin = new Thickness(0, 20, 0, 0) };

            sp.Children.Add(new TextBlock { Text = "Логин" });
            sp.Children.Add(tbLogin);
            sp.Children.Add(new TextBlock { Text = "Пароль", Margin = new Thickness(0, 10, 0, 5) });
            sp.Children.Add(pbPass);
            sp.Children.Add(new TextBlock { Text = "Дата рождения", Margin = new Thickness(0, 10, 0, 5) });
            sp.Children.Add(dpBirth);
            sp.Children.Add(btnOk);

            btnOk.Click += (s, e) =>
            {
                if (users.Any(u => u.Login.Equals(tbLogin.Text, StringComparison.OrdinalIgnoreCase)))
                {
                    MessageBox.Show("Такой логин уже существует!");
                    return;
                }

                var newUser = new User
                {
                    Login = tbLogin.Text.Trim(),
                    PasswordHash = GetHash(pbPass.Password),
                    BirthDate = dpBirth.SelectedDate ?? DateTime.Now
                };

                users.Add(newUser);
                SaveUsers();
                MessageBox.Show("Регистрация успешна! Теперь войдите.");
                win.Close();
            };

            win.Content = sp;
            win.ShowDialog();
        }

        private void ShowMainMenu()
        {
            Title = $"Викторина — {currentUser.Login}";
            var panel = new StackPanel { Margin = new Thickness(50) };

            panel.Children.Add(new TextBlock { Text = "Главное меню", FontSize = 28, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 0, 0, 40) });

            AddButton(panel, "Начать новую викторину", StartNewQuiz);
            AddButton(panel, "Мои результаты", ShowMyResults);
            AddButton(panel, "Топ-20", ShowGlobalTop20);
            AddButton(panel, "Настройки", ShowSettings);
            AddButton(panel, "Выход", () => { currentUser = null; ShowLoginScreen(); });

            Content = panel;
        }

        private void AddButton(StackPanel p, string text, Action action)
        {
            var btn = new Button { Content = text, Height = 55, Margin = new Thickness(0, 12,0,0), FontSize = 16 };
            btn.Click += (s, e) => action();
            p.Children.Add(btn);
        }

        // ===================== ВИКТОРИНА =====================
        private void StartNewQuiz()
        {
            var win = new Window { Title = "Выбор темы", Width = 450, Height = 400, Owner = this };
            var sp = new StackPanel { Margin = new Thickness(20) };

            var lb = new ListBox { FontSize = 15 };
            lb.Items.Add("Смешанная викторина");
            foreach (var q in quizzes) lb.Items.Add(q.Name);

            var btnStart = new Button { Content = "Начать (20 вопросов)", Height = 45, Margin = new Thickness(0, 20,0,0) };

            btnStart.Click += (s, e) =>
            {
                if (lb.SelectedIndex == -1) return;
                win.Close();

                Quiz selected = lb.SelectedIndex == 0 ? null : quizzes[lb.SelectedIndex - 1];
                StartQuizSession(selected);
            };

            sp.Children.Add(new TextBlock { Text = "Выберите раздел знаний:", FontSize = 18 });
            sp.Children.Add(lb);
            sp.Children.Add(btnStart);
            win.Content = sp;
            win.ShowDialog();
        }

        private void StartQuizSession(Quiz selectedQuiz)
        {
            List<Question> questions;

            if (selectedQuiz == null) // Смешанная
            {
                var all = quizzes.SelectMany(q => q.Questions).ToList();
                questions = all.OrderBy(x => Guid.NewGuid()).Take(20).ToList();
            }
            else
            {
                questions = selectedQuiz.Questions.OrderBy(x => Guid.NewGuid()).Take(20).ToList();
            }

            if (questions.Count == 0)
            {
                MessageBox.Show("Нет вопросов в этой викторине.");
                return;
            }

            int currentIndex = 0;
            int score = 0;

            var quizWin = new Window { Title = "Викторина", Width = 800, Height = 550, Owner = this, WindowState = WindowState.Normal };

            void ShowQuestion()
            {
                var q = questions[currentIndex];
                var sp = new StackPanel { Margin = new Thickness(30) };

                sp.Children.Add(new TextBlock { Text = $"Вопрос {currentIndex + 1} из 20", FontSize = 18 });
                sp.Children.Add(new TextBlock { Text = q.Text, FontSize = 20, Margin = new Thickness(0, 20,0,0), TextWrapping = TextWrapping.Wrap });

                var checkList = new List<CheckBox>();
                foreach (var ans in q.Answers)
                {
                    var cb = new CheckBox { Content = ans.Text, Margin = new Thickness(5), FontSize = 15 };
                    sp.Children.Add(cb);
                    checkList.Add(cb);
                }

                var btnNext = new Button { Content = currentIndex == 19 ? "Завершить викторину" : "Следующий вопрос", Height = 45, Margin = new Thickness(0, 30,0,0) };

                btnNext.Click += (s, e) =>
                {
                    // Проверка ответа
                    bool correct = true;
                    for (int i = 0; i < q.Answers.Count; i++)
                    {
                        bool userChecked = checkList[i].IsChecked == true;
                        if (userChecked != q.Answers[i].IsCorrect)
                            correct = false;
                    }
                    if (correct) score++;

                    currentIndex++;
                    if (currentIndex < 20)
                        ShowQuestion();
                    else
                        FinishQuiz(score, selectedQuiz?.Name ?? "Смешанная");
                };

                sp.Children.Add(btnNext);
                quizWin.Content = sp;
            }

            ShowQuestion();
            quizWin.ShowDialog();
        }

        private void FinishQuiz(int score, string quizName)
        {
            var result = new QuizResult { QuizName = quizName, Score = score, Date = DateTime.Now };
            currentUser.Results.Add(result);
            SaveUsers();

            MessageBox.Show($"Викторина завершена!\n\nПравильных ответов: {score} из 20\n\nМесто в рейтинге будет обновлено.",
                "Результат", MessageBoxButton.OK, MessageBoxImage.Information);

            ShowMainMenu();
        }

        private void ShowMyResults()
        {
            var text = "Мои результаты:\n\n";
            foreach (var r in currentUser.Results.OrderByDescending(r => r.Date))
            {
                text += $"{r.Date:dd.MM.yyyy HH:mm} — {r.QuizName} → {r.Score}/20\n";
            }
            MessageBox.Show(text, "Мои результаты");
        }

        private void ShowGlobalTop20()
        {
            var allResults = users.SelectMany(u => u.Results.Select(r => new { u.Login, r.QuizName, r.Score, r.Date }))
                                  .OrderByDescending(x => x.Score)
                                  .Take(20)
                                  .ToList();

            string text = "ТОП-20 (по лучшему результату):\n\n";
            for (int i = 0; i < allResults.Count; i++)
            {
                text += $"{i + 1}. {allResults[i].Login} — {allResults[i].QuizName} ({allResults[i].Score}/20)\n";
            }
            MessageBox.Show(text, "Топ-20");
        }

        private void ShowSettings()
        {
            // Простая реализация
            MessageBox.Show($"Настройки пользователя {currentUser.Login}\n\nИзменение пароля и даты рождения — в следующей версии.", "Настройки");
        }
    }

}
