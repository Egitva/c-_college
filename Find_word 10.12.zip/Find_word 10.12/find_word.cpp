﻿// find_word.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <windows.h>

struct SearchResult {
    std::string filePath;
    int count;
    std::vector<size_t> positions;
};

void searchInFile(const std::string& filePath, const std::string& target, SearchResult& res) {
    std::ifstream file(filePath);
    if (!file) return;

    std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    file.close();

    size_t pos = content.find(target);
    res.filePath = filePath;
    res.count = 0;
    res.positions.clear();

    while (pos != std::string::npos) {
        res.count++;
        res.positions.push_back(pos);
        pos = content.find(target, pos + target.length());
    }
}

void searchInDirectory(const std::string& dirPath, const std::string& target, std::vector<SearchResult>& results) {
    std::string searchPath = dirPath + "\\*";
    WIN32_FIND_DATAA findData;
    HANDLE hFind = FindFirstFileA(searchPath.c_str(), &findData);

    if (hFind == INVALID_HANDLE_VALUE) return;

    do {
        std::string name = findData.cFileName;
        if (name == "." || name == "..") continue;

        std::string fullPath = dirPath + "\\" + name;

        if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            searchInDirectory(fullPath, target, results);
        }
        else {
            SearchResult res;
            searchInFile(fullPath, target, res);
            if (res.count > 0) {
                results.push_back(res);
            }
        }
    } while (FindNextFileA(hFind, &findData) != 0);

    FindClose(hFind);
}

void replaceInFile(const std::string& filePath, const std::string& target, const std::string& replacement) {
    std::ifstream inFile(filePath);
    if (!inFile) return;

    std::string content((std::istreambuf_iterator<char>(inFile)), std::istreambuf_iterator<char>());
    inFile.close();

    size_t pos = 0;
    while ((pos = content.find(target, pos)) != std::string::npos) {
        content.replace(pos, target.length(), replacement);
        pos += replacement.length();
    }

    std::ofstream outFile(filePath);
    outFile << content;
    outFile.close();
}

void deleteInFile(const std::string& filePath, const std::string& target) {
    replaceInFile(filePath, target, "");
}

void generateReport(const std::vector<SearchResult>& results, const std::string& target) {
    std::ofstream report("report.txt");
    report << "Отчет по поиску слова: \"" << target << "\"\n";
    report << "========================================\n";
    for (const auto& res : results) {
        report << "Файл: " << res.filePath << "\n";
        report << "Найдено совпадений: " << res.count << "\n";
        report << "Позиции: ";
        for (size_t pos : res.positions) {
            report << pos << " ";
        }
        report << "\n----------------------------------------\n";
    }
    report.close();
}

int main() {
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
    std::string folderPath, targetWord, choice;

    std::cout << "Введите путь к папке: ";
    std::getline(std::cin, folderPath);

    std::cout << "Введите искомое слово: ";
    std::getline(std::cin, targetWord);

    DWORD attr = GetFileAttributesA(folderPath.c_str());
    if (attr == INVALID_FILE_ATTRIBUTES || !(attr & FILE_ATTRIBUTE_DIRECTORY)) {
        std::cout << "Ошибка: указанный путь не является папкой.\n";
        return 1;
    }

    std::vector<SearchResult> results;
    searchInDirectory(folderPath, targetWord, results);

    if (results.empty()) {
        std::cout << "Слово не найдено.\n";
    }
    else {
        std::cout << "Найдено в " << results.size() << " файле(ах).\n";
        generateReport(results, targetWord);
        std::cout << "Отчет сохранен в report.txt\n";

        std::cout << "Хотите заменить или удалить слово? (replace/delete/no): ";
        std::getline(std::cin, choice);
        if (choice == "replace" || choice == "delete") {
            std::string replacement;
            if (choice == "replace") {
                std::cout << "Введите слово для замены: ";
                std::getline(std::cin, replacement);
            }

            for (const auto& res : results) {
                if (choice == "replace") {
                    replaceInFile(res.filePath, targetWord, replacement);
                }
                else {
                    deleteInFile(res.filePath, targetWord);
                }
            }
            std::cout << "Операция выполнена.\n";
        }
    }
    return 0;
}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
