﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml.XPath;
using HtmlAgilityPack;

namespace parse_avito
{
    internal class Program
    {
        static void Main()
        {
            var web = new HtmlWeb();
            var doc = web.Load("https://www.avito.ru/");

            string xPath = "//h2";

            var nodes = doc.DocumentNode.SelectNodes(xPath);

            if (nodes != null)
            {
                foreach (var node in nodes)
                {
                    Console.WriteLine($"Текст: {node.InnerText.Trim()}");
                }
            }
            else
            {
                Console.WriteLine("Элементы по данному XPath не найдены.");
            }
        }
    }
}
